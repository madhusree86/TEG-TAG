namespace BackendAPI2.Models
{
    public class TrafficData
    {
        public int Id { get; set; }
        public string Road { get; set; }
        public string Condition { get; set; }
        public int CongestionLevel { get; set; }
    }
}
