using Microsoft.AspNetCore.Mvc;
using BackendAPI2.Models;
using System.Threading.Tasks;

namespace BackendAPI2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TrafficController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<TrafficData>> Get()
        {
            // Simulate longer delay
            await Task.Delay(3000);

            var trafficData = new TrafficData
            {
                Id = 1,
                Road = "Main Street",
                Condition = "Heavy",
                CongestionLevel = 8
            };

            return Ok(trafficData);
        }
    }
}
