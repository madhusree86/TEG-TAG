using Microsoft.AspNetCore.Mvc;
using BackendAPI1.Models;
using System.Threading.Tasks;

namespace BackendAPI1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherController : ControllerBase
    {
        [HttpGet]
        public async Task<ActionResult<WeatherData>> Get()
        {
            // Simulate delay
            await Task.Delay(2000);

            var weatherData = new WeatherData
            {
                Id = 1,
                Location = "New York",
                Temperature = 20.5,
                Condition = "Sunny"
            };

            return Ok(weatherData);
        }
    }
}
