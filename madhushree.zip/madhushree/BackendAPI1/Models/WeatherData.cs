namespace BackendAPI1.Models
{
    public class WeatherData
    {
        public int Id { get; set; }
        public string Location { get; set; }
        public double Temperature { get; set; }
        public string Condition { get; set; }
    }
}
