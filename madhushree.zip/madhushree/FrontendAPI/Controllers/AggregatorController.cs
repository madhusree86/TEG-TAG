using Microsoft.AspNetCore.Mvc;
using FrontendAPI.Models;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.Json;

namespace FrontendAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AggregatorController : ControllerBase
    {
        private readonly IHttpClientFactory _clientFactory;

        public AggregatorController(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        [HttpGet]
        public async Task<ActionResult<AggregatedData>> Get()
        {
            var client = _clientFactory.CreateClient();

            // Create tasks for both API calls
            var weatherTask = client.GetStringAsync("http://localhost:5001/api/weather");
            var trafficTask = client.GetStringAsync("http://localhost:5002/api/traffic");

            // Wait for both tasks to complete
            await Task.WhenAll(weatherTask, trafficTask);

            // Parse the results
            var weather = JsonSerializer.Deserialize<WeatherData>(await weatherTask);
            var traffic = JsonSerializer.Deserialize<TrafficData>(await trafficTask);

            var result = new AggregatedData
            {
                Weather = weather,
                Traffic = traffic
            };

            return Ok(result);
        }

        [HttpPost]
        public ActionResult<string> Post([FromBody] object data)
        {
            // Example POST endpoint
            return Ok("Data received successfully");
        }
    }
}
