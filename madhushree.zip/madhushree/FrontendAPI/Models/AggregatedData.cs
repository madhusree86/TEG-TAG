namespace FrontendAPI.Models
{
    public class WeatherData
    {
        public int Id { get; set; }
        public string Location { get; set; }
        public double Temperature { get; set; }
        public string Condition { get; set; }
    }

    public class TrafficData
    {
        public int Id { get; set; }
        public string Road { get; set; }
        public string Condition { get; set; }
        public int CongestionLevel { get; set; }
    }

    public class AggregatedData
    {
        public WeatherData Weather { get; set; }
        public TrafficData Traffic { get; set; }
    }
}
